config = {}


config.RefreshTime = 100